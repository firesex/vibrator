Mmh Vibrator!
=============

Mmh Vibrator! is a Firefox OS open webapp that makes your phone sensual.

Mmh Vibrator! intends to give you relaxation and pleasure. You want to spice your
life? Try how can vibrations feel? Try some new experiments or just give your girlfriend a good
massage? This application is for you.

*Warning:* this will *not* transform your phone into a real vibrator.
It will give you much less sensations. Nevertheless, you can try this app as a beginning, and buy a vibrator
if you like it.

Mmh Vibrator! comes with:
- 3 standard vibration modes (slow, medium, continue)
- + 1 random mode (create random vibration times)
- + 1 custom mode where you can custom the vibrations!

Don't hesitate to send me your feedbacks or suggestion about the app!

An online version is available at http://firesex.github.io/vibrator
make sure to visit it with a smartphone (computers don't vibrate) from Firefox, Chrome / Chromium or Firefox OS / B2G.

Explicit content
----------------

This repository won't contain any pornographic content, only soft pictures and maybe a little rude language. I tell this here in order to not being banned by the Github team :)

If you find any wrong content, please tell me and I'll remove it.

Licensing
---------

The program and its sources are released under the GNU GPLv3 (see the LICENSE file).

The font used is "Cartoonist Hand", created by ShyFonts and released under [http://www.fontsquirrel.com/license/SF-Cartoonist-Hand](ShyFonts font license).

All the used images of girls have been created by OpenClips and released under the CC0 (Creative Commons public domain):
http://pixabay.com/en/users/OpenClips/

Except for the file "Glass_Dildo.JPG" which has been created by JennyD and released under the CC-BY license:
https://commons.wikimedia.org/wiki/File:Glass_Dildo.JPG

"massage.jpg" has been created by Lucas Frasca and released under the CC-BY-NC-SA license: https://secure.flickr.com/photos/lucasfrasca/12405482565

"smartphone_navy.png" has been created by agomjo and released in the public domain: https://openclipart.org/detail/191409/smartphone-display-color-navy-by-agomjo-191409

"battery.svg" has been created by (an) Anonymous and is released in the punlic domain: https://openclipart.org/detail/116089/ftlaptop-battery-by-anonymous

"edit.svg", "add.svg", "del.svg" and "check.svg" have certainly been created by Fawad Hassan and Robert Nyman for their example of Todo Firefox OS application: https://hacks.mozilla.org/2013/06/building-a-todo-app-for-firefox-os-part-1/

Changelog
---------

###v1.0###
first release
